**Task #03:** All variables declared of type `double`
