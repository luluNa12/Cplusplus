**Task #01:** Write C++ statements that include the header files iostream and string.
