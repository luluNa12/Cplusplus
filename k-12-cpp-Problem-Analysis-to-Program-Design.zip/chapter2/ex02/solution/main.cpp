#include <iostream> 

using namespace std; 
 
int main()  
{
	cout << "CCCCCCCCC       ++              ++" << endl;
	cout << "CC              ++              ++" << endl;
	cout << "CC        ++++++++++++++  +++++++++++++++" << endl;
	cout << "CC        ++++++++++++++  +++++++++++++++" << endl;
	cout << "CC              ++              ++" << endl;
	cout << "CCCCCCCCC       ++              ++" << endl;
	cout << endl;

	return 0;
}