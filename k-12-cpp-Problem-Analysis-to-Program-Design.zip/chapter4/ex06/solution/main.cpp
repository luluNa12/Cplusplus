   
#include <iostream>
#include <iomanip>

using namespace std;

const int NUMBER_OF_COOKIES_IN_BOX = 24;
const int CONTAINER_CAPACITY = 75;

int main()
{
	int numberOfCookies;
    int numberOfBoxes;
    int numberOfContainers; 
    int leftoverCookies;
    int leftoverBoxes;
 
	cout << "Enter the total number of cookies: ";
	cin >> numberOfCookies;
	cout << endl;

	numberOfBoxes = numberOfCookies / NUMBER_OF_COOKIES_IN_BOX;
    leftoverCookies = numberOfCookies % NUMBER_OF_COOKIES_IN_BOX;

    numberOfContainers = numberOfBoxes / CONTAINER_CAPACITY;
    leftoverBoxes = numberOfBoxes % CONTAINER_CAPACITY;

    cout << "The number of cookie boxes needed to hold the cookies: "
         << numberOfBoxes << endl;

    if (leftoverCookies > 0)
    {
        cout << "Leftover cookies: " << leftoverCookies << endl;
    }

    cout << "The number of containers needed to store the cookie boxes: "
         << numberOfContainers << endl;
    if (leftoverBoxes > 0)
    {
        cout << "Leftover boxes: " << leftoverBoxes << endl;
    }

	return 0;
}
