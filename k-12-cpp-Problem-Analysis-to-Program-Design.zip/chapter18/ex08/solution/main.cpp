#include <iostream>
#include <cmath>
#include "linkedStack.h"
 
using namespace std;
 
int main() 
{
    linkedStackType<int> stack;

    int num;
    int base = 2;

    cout << "Enter a nonnegative integer: ";
    cin >> num;
    cout << endl;

    while (num > 0)
    {
        stack.push(num);
        num = num / base;
    }

    cout << "The equivalent binary num is: ";

    while (!stack.isEmptyStack())
    {
        cout << stack.top() % base;
        stack.pop();
    }

    cout << endl;

    return 0;
}