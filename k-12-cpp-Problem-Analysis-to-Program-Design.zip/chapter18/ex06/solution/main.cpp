#include <iostream>
#include <cmath>
#include "linkedStack.h"
 
using namespace std;
 
bool isPrime(long num); 

int main()
{
    linkedStackType<long> stack;
    long num;
    long temp;
    long factor;
	
    cout << "Enter a positive integer greater than 1: ";
    cin >> num;
    cout << endl;

    while (num <= 1)
    {
        cout << "You must enter a positive integer greater than 1: " << endl;
        cin >> num;
    }

    cout << "The prime factoriztion of " << num << ": ";

    if (isPrime(num))
    {
        cout << num << endl;
        return 0;
    }
	
    stack.initializeStack();

    temp = num;

    factor = 2;

    while (temp > 1)
        if (temp % 2 == 0)
        {
            stack.push(2);
            temp = temp / 2;
        }
        else
            break;

    factor = 3;

    while (temp > 1 && (factor <= num / 2))
    {
        if (!isPrime(factor))
            factor += 2;
        else if (temp % factor == 0)
        {
            stack.push(factor);
            temp = temp / factor;
        }
        else
            factor += 2;
    }

    while (!stack.isEmptyStack())
    {
        cout << stack.top() << " ";
        stack.pop();
    }

    cout << endl;

    return 0;
}

bool isPrime(long num)
{
    bool isPrimeNum;

    int sqrtNum;
    int divisor = 3;

    if (num == 2)
        isPrimeNum = true;
    else if (num % 2 == 0)
        isPrimeNum = false;
    else
    {
        isPrimeNum = true;

        sqrtNum = static_cast<int>(pow(static_cast<double>(num), 0.5));

        while (divisor <= sqrtNum)
        {
            if (num % divisor == 0)
            {
                isPrimeNum = false;
                break;
            }
            else
                divisor = divisor + 2;
        }
    }

    return isPrimeNum;
}