#include <iostream>
#include <cmath>
#include "linkedStack.h"
 
using namespace std;
 
int main() 
{
    linkedStackType<int> stack;

    int decimalNum;
    int bitWeight = 0;
    int binaryNum;
    int bit;

    cout << "Enter a binary number: ";
    cin >> binaryNum;
    cout << endl;

    while (binaryNum > 0)
    {
        stack.push(binaryNum % 10);
        bitWeight++;
        binaryNum = binaryNum / 10;
    }

    decimalNum = 0;

    while (!stack.isEmptyStack())
    {
        bitWeight--;
        bit = stack.top();
        stack.pop(); 
        decimalNum = decimalNum + bit * static_cast<int>(pow(2.0, bitWeight));
    }

    cout << "The equivalent decimal num is: " << decimalNum << endl;

    return 0;
}