#include <iostream>
#include "myStack.h"
  
using namespace std;
 
int main() 
{
    char ch;
    char stackCh;
    stackType<char> stack(100);

    stack.initializeStack();
	
    cout << "Enter an arithmetic expression ending with ;" << endl;

    cin.get(ch);
    while (ch != ';')
    {
        cout << ch;

        switch (ch)
        {
        case '[': 
        case '{': 
        case '(':	
            if (!stack.isFullStack())
                stack.push(ch);
            else
            {
                cout << "Stack overflow. Program terminates!!" << endl;
                return 1;
            }
            break;
		case ']':
		case '}':
		case ')':	
            if (!stack.isEmptyStack())
            {
                stackCh = stack.top();
                stack.pop();

                if (!((ch == ')' && stackCh == '(') ||
                      (ch == '}' && stackCh == '{') ||
                       (ch == ']' && stackCh == '[')) )
                {
                    cout << endl
                         << "Expression does not have matching grouping symbols." 
                         << endl;
                    return 1;
                }
            }
            else
            {
                cout << endl
                     << "Expression does not have matching grouping symbols." 
                     << endl;
                return 1;
            }
        }

        cin.get(ch);
    }//end while 

    if (stack.isEmptyStack())
        cout << endl 
            << "Expression has matching grouping symbol" << endl;
    else
        cout << endl
             << "Expression does not have matching grouping symbols" << endl;

    return 0;

}//end main
